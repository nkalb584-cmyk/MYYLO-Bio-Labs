import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          50: "#f1f4f9",
          100: "#dde4ef",
          700: "#1c3558",
          800: "#12284a",
          900: "#0b1c36",
        },
        teal: {
          50: "#effaf9",
          100: "#d3f3f0",
          500: "#14b8a6",
          600: "#0d9488",
          700: "#0f766e",
        },
        paper: "#f8fafb",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(11,28,54,0.05), 0 4px 16px rgba(11,28,54,0.06)",
      },
    },
  },
  plugins: [],
};

export default config;
