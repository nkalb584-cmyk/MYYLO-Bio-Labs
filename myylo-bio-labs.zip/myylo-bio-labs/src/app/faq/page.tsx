import type { Metadata } from "next";
import { faqGroups } from "@/lib/faq";

export const metadata: Metadata = {
  title: "FAQ",
  description: "Answers about ordering, shipping, storage, handling, and returns at MYYLO bio Labs.",
};

export default function FaqPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqGroups.flatMap((g) =>
      g.items.map((i) => ({
        "@type": "Question",
        name: i.q,
        acceptedAnswer: { "@type": "Answer", text: i.a },
      }))
    ),
  };

  return (
    <div className="container-page max-w-3xl py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <h1 className="text-4xl font-bold">Frequently asked questions</h1>
      {faqGroups.map((g) => (
        <section key={g.title} className="mt-10">
          <h2 className="text-xl font-semibold">{g.title}</h2>
          <div className="mt-4 divide-y divide-navy-100 rounded-2xl border border-navy-100 bg-white">
            {g.items.map((i) => (
              <details key={i.q} className="p-5">
                <summary className="cursor-pointer font-semibold">{i.q}</summary>
                <p className="mt-3 text-sm leading-relaxed text-slate-700">{i.a}</p>
              </details>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
