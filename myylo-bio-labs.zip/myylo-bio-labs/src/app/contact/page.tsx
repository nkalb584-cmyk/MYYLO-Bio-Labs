import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description: "Contact MYYLO bio Labs about orders, batch documentation, or account questions.",
};

export default function ContactPage() {
  return (
    <div className="container-page max-w-2xl py-12">
      <h1 className="text-4xl font-bold">Contact us</h1>
      <p className="mb-8 mt-3 text-slate-700">
        Questions about an order or batch documentation? Send us a message. We cannot provide dosing, administration,
        or usage guidance.
      </p>
      <ContactForm />
    </div>
  );
}
