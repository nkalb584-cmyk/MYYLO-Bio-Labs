import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getLegalDoc, legalDocs } from "@/lib/legal";

export function generateStaticParams() {
  return legalDocs.map((d) => ({ doc: d.slug }));
}

export function generateMetadata({ params }: { params: { doc: string } }): Metadata {
  const d = getLegalDoc(params.doc);
  return d ? { title: d.title, description: d.description } : {};
}

export default function LegalPage({ params }: { params: { doc: string } }) {
  const d = getLegalDoc(params.doc);
  if (!d) notFound();

  return (
    <div className="container-page max-w-3xl py-12">
      <h1 className="text-4xl font-bold">{d.title}</h1>
      <div className="prose-legal">
        {d.sections.map((s) => (
          <section key={s.h}>
            <h2>{s.h}</h2>
            {s.p.map((para) => (
              <p key={para}>{para}</p>
            ))}
          </section>
        ))}
      </div>
    </div>
  );
}
