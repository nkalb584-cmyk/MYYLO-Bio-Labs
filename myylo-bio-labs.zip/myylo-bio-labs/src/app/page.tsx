import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import NewsletterForm from "@/components/NewsletterForm";
import { products } from "@/data/products";
import { faqGroups } from "@/lib/faq";

const highlights = [
  {
    title: "Third-party tested",
    body: "Independent laboratory analysis of every production batch before release.",
  },
  {
    title: "HPLC purity ≥98%",
    body: "Reverse-phase HPLC purity verification, with mass spectrometry confirming molecular identity.",
  },
  {
    title: "COA for every batch",
    body: "A Certificate of Analysis tied to your batch number, available to download.",
  },
];

export default function HomePage() {
  const featured = products.filter((p) => p.featured).slice(0, 4);
  const faqs = faqGroups.flatMap((g) => g.items).slice(0, 3);

  return (
    <>
      <section className="bg-gradient-to-b from-white to-paper">
        <div className="container-page grid items-center gap-10 py-20 md:grid-cols-[1.2fr_1fr] md:py-28">
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-teal-700">MYYLO bio Labs</p>
            <h1 className="mt-4 text-4xl font-bold leading-tight sm:text-5xl">
              Research-grade peptides for laboratory science
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-700">
              High-purity synthetic peptides supplied with full analytical documentation, for in-vitro research use
              only.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/shop" className="btn-primary">
                Shop peptides
              </Link>
              <Link href="/quality" className="btn-secondary">
                View quality standards
              </Link>
            </div>
          </div>
          <dl className="card grid grid-cols-3 divide-x divide-navy-100 p-6 text-center">
            <div className="px-2">
              <dt className="text-xs uppercase tracking-wider text-slate-600">Purity</dt>
              <dd className="mt-2 text-2xl font-bold text-teal-700">≥98%</dd>
            </div>
            <div className="px-2">
              <dt className="text-xs uppercase tracking-wider text-slate-600">Catalog</dt>
              <dd className="mt-2 text-2xl font-bold text-teal-700">{products.length}</dd>
            </div>
            <div className="px-2">
              <dt className="text-xs uppercase tracking-wider text-slate-600">Documentation</dt>
              <dd className="mt-2 text-2xl font-bold text-teal-700">COA</dd>
            </div>
          </dl>
        </div>
      </section>

      <section className="container-page py-16">
        <div className="flex items-end justify-between">
          <h2 className="text-3xl font-bold">Featured research compounds</h2>
          <Link href="/shop" className="text-sm font-semibold text-teal-700 hover:underline">
            View all
          </Link>
        </div>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-page">
          <h2 className="text-3xl font-bold">Quality you can verify</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {highlights.map((h) => (
              <div key={h.title} className="card p-6">
                <div className="h-1 w-10 rounded bg-teal-600" />
                <h3 className="mt-4 text-lg font-semibold">{h.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-700">{h.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-16">
        <div className="flex items-end justify-between">
          <h2 className="text-3xl font-bold">Common questions</h2>
          <Link href="/faq" className="text-sm font-semibold text-teal-700 hover:underline">
            All FAQs
          </Link>
        </div>
        <div className="mt-6 divide-y divide-navy-100 rounded-2xl border border-navy-100 bg-white">
          {faqs.map((f) => (
            <details key={f.q} className="group p-5">
              <summary className="cursor-pointer list-none font-semibold marker:hidden">{f.q}</summary>
              <p className="mt-3 text-sm leading-relaxed text-slate-700">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="container-page">
        <div className="rounded-2xl bg-navy-900 px-6 py-12 text-white sm:px-12">
          <h2 className="text-2xl font-bold text-white">Stay informed</h2>
          <p className="mt-2 max-w-lg text-sm text-navy-100">
            Occasional updates on new catalog additions and quality documentation.
          </p>
          <NewsletterForm />
        </div>
      </section>
    </>
  );
}
