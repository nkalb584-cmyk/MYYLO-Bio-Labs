import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About",
  description: "MYYLO bio Labs supplies research-grade peptides with documented purity testing for in-vitro laboratory research.",
};

const steps = [
  { t: "Synthesis", d: "Peptides are produced by solid-phase synthesis and purified by preparative chromatography." },
  { t: "Purity analysis", d: "Reverse-phase HPLC determines purity. Our specification is 98% or higher." },
  { t: "Identity confirmation", d: "Mass spectrometry confirms the molecular weight matches the expected sequence." },
  { t: "Batch documentation", d: "Results are recorded on a Certificate of Analysis linked to a unique batch number." },
  { t: "Lyophilized packaging", d: "Product is lyophilized, sealed, labeled with batch details, and shipped for cold storage on arrival." },
];

export default function AboutPage() {
  return (
    <div className="container-page max-w-4xl py-12">
      <h1 className="text-4xl font-bold">About MYYLO bio Labs</h1>

      <section className="mt-8">
        <h2 className="text-2xl font-semibold">Our mission</h2>
        <p className="mt-3 leading-relaxed text-slate-700">
          MYYLO bio Labs supplies research-grade peptides to laboratories that need consistent, well-documented
          materials for in-vitro work. We focus on analytical transparency: every batch is tested, and every result is
          documented.
        </p>
      </section>

      <section className="mt-10">
        <h2 className="text-2xl font-semibold">Quality standards</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-slate-700">
          <li>Minimum 98% purity by HPLC for every catalog compound.</li>
          <li>Identity confirmed by mass spectrometry.</li>
          <li>Third-party laboratory verification of production batches.</li>
          <li>Batch-level traceability and a Certificate of Analysis for every lot.</li>
        </ul>
      </section>

      <section className="mt-10">
        <h2 className="text-2xl font-semibold">Our testing process</h2>
        <ol className="mt-4 space-y-4">
          {steps.map((s, i) => (
            <li key={s.t} className="card flex gap-4 p-5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-teal-50 text-sm font-bold text-teal-700">
                {i + 1}
              </span>
              <div>
                <h3 className="font-semibold">{s.t}</h3>
                <p className="mt-1 text-sm text-slate-700">{s.d}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-10 rounded-2xl bg-teal-50 p-6 text-sm leading-relaxed text-teal-700">
        MYYLO bio Labs products are for in-vitro research and laboratory use only. They are not drugs, supplements, or
        cosmetics and are not for human or animal consumption. See our{" "}
        <Link href="/legal/research-use" className="font-semibold underline">
          Research Use Policy
        </Link>
        .
      </section>
    </div>
  );
}
