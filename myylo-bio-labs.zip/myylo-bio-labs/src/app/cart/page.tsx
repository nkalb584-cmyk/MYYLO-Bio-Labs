"use client";

import Link from "next/link";
import { useState } from "react";
import VialImage from "@/components/VialImage";
import { formatPrice } from "@/data/products";
import { FREE_SHIPPING_THRESHOLD, totals, useCart, useHydrated } from "@/lib/cart";

export default function CartPage() {
  const { lines, setQty, remove } = useCart();
  const hydrated = useHydrated();
  const [confirmed, setConfirmed] = useState(false);
  const [notice, setNotice] = useState(false);
  const { detailed, subtotal, shipping, total } = totals(hydrated ? lines : []);

  return (
    <div className="container-page py-12">
      <h1 className="text-4xl font-bold">Cart & checkout</h1>

      {!hydrated ? (
        <p className="mt-8 text-slate-600">Loading cart…</p>
      ) : detailed.length === 0 ? (
        <div className="card mt-8 p-12 text-center">
          <p className="text-slate-700">Your cart is empty.</p>
          <Link href="/shop" className="btn-primary mt-5">
            Browse peptides
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
          <ul className="card divide-y divide-navy-100">
            {detailed.map(({ product, qty }) => (
              <li key={product.slug} className="flex gap-4 p-5">
                <VialImage product={product} className="h-28 w-24 shrink-0 rounded-lg" />
                <div className="flex flex-1 flex-col">
                  <div className="flex justify-between gap-3">
                    <div>
                      <Link href={`/shop/${product.slug}`} className="font-semibold hover:text-teal-700">
                        {product.name}
                      </Link>
                      <p className="text-sm text-slate-600">
                        {product.size} · {formatPrice(product.price)} each
                      </p>
                    </div>
                    <p className="font-semibold">{formatPrice(product.price * qty)}</p>
                  </div>
                  <div className="mt-auto flex items-center justify-between pt-4">
                    <div className="flex items-center rounded-lg border border-navy-100">
                      <button
                        type="button"
                        aria-label={`Decrease quantity of ${product.name}`}
                        className="h-9 w-9 hover:bg-navy-50"
                        onClick={() => setQty(product.slug, qty - 1)}
                      >
                        −
                      </button>
                      <span className="w-8 text-center text-sm" aria-live="polite">
                        {qty}
                      </span>
                      <button
                        type="button"
                        aria-label={`Increase quantity of ${product.name}`}
                        className="h-9 w-9 hover:bg-navy-50"
                        onClick={() => setQty(product.slug, qty + 1)}
                      >
                        +
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(product.slug)}
                      className="text-sm text-slate-600 underline hover:text-navy-900"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>

          <aside className="card h-fit p-6" aria-label="Order summary">
            <h2 className="text-lg font-semibold">Order summary</h2>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex justify-between">
                <dt>Subtotal</dt>
                <dd>{formatPrice(subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Shipping (estimate)</dt>
                <dd>{shipping === 0 ? "Free" : formatPrice(shipping)}</dd>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-slate-600">
                  Add {formatPrice(FREE_SHIPPING_THRESHOLD - subtotal)} more for free shipping.
                </p>
              )}
              <div className="flex justify-between border-t border-navy-100 pt-3 text-base font-bold">
                <dt>Estimated total</dt>
                <dd>{formatPrice(total)}</dd>
              </div>
            </dl>

            <div className="mt-6 flex items-start gap-3">
              <input
                id="confirm"
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                className="mt-1 h-5 w-5 shrink-0 accent-teal-700"
                required
              />
              <label htmlFor="confirm" className="text-sm leading-relaxed text-slate-700">
                I confirm I am a qualified researcher, I am 21+, and these products are for laboratory research use
                only and not for human or animal consumption.
              </label>
            </div>

            <button type="button" className="btn-accent mt-6 w-full" disabled={!confirmed} onClick={() => setNotice(true)}>
              Place order
            </button>
            {notice && (
              <p role="status" className="mt-4 rounded-lg bg-navy-50 p-3 text-xs text-navy-800">
                Checkout is a placeholder. Connect a payment processor in{" "}
                <code className="font-mono">src/app/cart/page.tsx</code> to accept orders.
              </p>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
