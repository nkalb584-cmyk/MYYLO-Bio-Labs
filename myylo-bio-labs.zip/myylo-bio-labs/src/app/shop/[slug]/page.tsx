import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "@/components/AddToCartButton";
import ProductCard from "@/components/ProductCard";
import VialImage from "@/components/VialImage";
import { formatPrice, getProduct, getRelated, products } from "@/data/products";
import { SITE_URL } from "@/lib/site";

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const p = getProduct(params.slug);
  if (!p) return {};
  const title = `${p.name} ${p.size}`;
  const description = `${p.name} (${p.size}) research peptide, ${p.purity} purity. For in-vitro laboratory research use only.`;
  return {
    title,
    description,
    alternates: { canonical: `/shop/${p.slug}` },
    openGraph: { title: `${title} | MYYLO bio Labs`, description, url: `/shop/${p.slug}`, type: "website" },
  };
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const p = getProduct(params.slug);
  if (!p) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `${p.name} ${p.size}`,
    description: p.description,
    sku: p.id,
    category: p.category,
    brand: { "@type": "Brand", name: "MYYLO bio Labs" },
    url: `${SITE_URL}/shop/${p.slug}`,
    offers: {
      "@type": "Offer",
      price: p.price.toFixed(2),
      priceCurrency: "USD",
      availability: p.inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      url: `${SITE_URL}/shop/${p.slug}`,
    },
  };

  const specs: [string, string][] = [
    ["Size", p.size],
    ["Purity", p.purity],
    ["Molecular formula", p.formula],
    ["Molecular weight", p.molecularWeight],
    ["CAS number", p.cas ?? "Not assigned / not applicable"],
    ["Storage", p.storage],
    ["Category", p.category],
  ];

  return (
    <div className="container-page py-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav aria-label="Breadcrumb" className="text-sm text-slate-600">
        <Link href="/shop" className="hover:text-teal-700">
          Shop
        </Link>{" "}
        / <span aria-current="page">{p.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <div className="card overflow-hidden">
          <VialImage product={p} className="w-full" />
        </div>

        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-teal-700">{p.category}</p>
          <h1 className="mt-2 text-3xl font-bold">
            {p.name} <span className="text-slate-500">{p.size}</span>
          </h1>
          <p className="mt-4 text-3xl font-bold">{formatPrice(p.price)}</p>
          <p className="mt-1 text-sm text-slate-600">{p.inStock ? "In stock" : "Out of stock"}</p>

          <p className="mt-5 leading-relaxed text-slate-700">{p.description}</p>

          <div className="mt-6">
            <AddToCartButton slug={p.slug} inStock={p.inStock} withQty />
          </div>
          <button type="button" className="btn-secondary mt-3 w-full sm:w-auto" disabled aria-disabled="true" title="COA download will be connected to your batch records">
            Download COA (placeholder)
          </button>

          <p className="mt-6 rounded-lg bg-teal-50 p-4 text-xs leading-relaxed text-teal-700">
            For in-vitro laboratory research use only. Not a drug, supplement, or cosmetic. Not for human or animal
            consumption.
          </p>
        </div>
      </div>

      <section className="mt-12">
        <h2 className="text-xl font-semibold">Specifications</h2>
        <dl className="card mt-4 divide-y divide-navy-100">
          {specs.map(([k, v]) => (
            <div key={k} className="grid gap-1 px-5 py-3 sm:grid-cols-[200px_1fr]">
              <dt className="text-sm font-medium text-slate-600">{k}</dt>
              <dd className="text-sm">{v}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mt-14">
        <h2 className="text-xl font-semibold">Related products</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {getRelated(p).map((r) => (
            <ProductCard key={r.id} product={r} />
          ))}
        </div>
      </section>
    </div>
  );
}
