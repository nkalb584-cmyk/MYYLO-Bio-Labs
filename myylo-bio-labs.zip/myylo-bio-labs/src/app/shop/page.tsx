import type { Metadata } from "next";
import ShopClient from "@/components/ShopClient";

export const metadata: Metadata = {
  title: "Shop Research Peptides",
  description:
    "Browse research-grade peptides from MYYLO bio Labs, each with HPLC purity verification and a Certificate of Analysis. For in-vitro laboratory use only.",
};

export default function ShopPage() {
  return (
    <div className="container-page py-12">
      <h1 className="text-4xl font-bold">Research peptides</h1>
      <p className="mt-3 max-w-2xl text-slate-700">
        All products are supplied for in-vitro laboratory research use only.
      </p>
      <div className="mt-8">
        <ShopClient />
      </div>
    </div>
  );
}
